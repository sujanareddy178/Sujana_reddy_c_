CREATE DATABASE IF NOT EXISTS inventory_stock CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci; USE inventory_stock;
CREATE TABLE IF NOT EXISTS users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),email VARCHAR(150) UNIQUE,password VARCHAR(255),role VARCHAR(20) DEFAULT 'admin');
CREATE TABLE IF NOT EXISTS categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) UNIQUE);
CREATE TABLE IF NOT EXISTS suppliers(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(150),phone VARCHAR(40),email VARCHAR(150),address TEXT);
CREATE TABLE IF NOT EXISTS products(id INT AUTO_INCREMENT PRIMARY KEY,sku VARCHAR(60) UNIQUE,name VARCHAR(150),category_id INT NULL,quantity INT DEFAULT 0,reorder_level INT DEFAULT 5,unit_price DECIMAL(10,2) DEFAULT 0,FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL);
CREATE TABLE IF NOT EXISTS stock_transactions(id INT AUTO_INCREMENT PRIMARY KEY,product_id INT,type ENUM('IN','OUT'),quantity INT,note VARCHAR(255),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(product_id) REFERENCES products(id));
INSERT IGNORE INTO users(name,email,password,role) VALUES('Administrator','admin@inventorypro.test','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.','admin');
INSERT IGNORE INTO categories(name) VALUES('Electronics'),('Stationery'),('Accessories');

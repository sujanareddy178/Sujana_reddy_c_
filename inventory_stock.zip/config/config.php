<?php
session_start();
define('DB_HOST','127.0.0.1'); define('DB_PORT','3307');
define('DB_NAME','inventory_stock'); define('DB_USER','root'); define('DB_PASS','');
define('BASE_URL','/inventory_stock');
function db(){static $p=null;if(!$p)$p=new PDO('mysql:host='.DB_HOST.';port='.DB_PORT.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);return $p;}

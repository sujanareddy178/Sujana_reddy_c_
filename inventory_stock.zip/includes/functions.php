<?php
require_once __DIR__.'/../config/config.php';
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function require_login(){if(empty($_SESSION['user'])){header('Location: '.BASE_URL.'/login.php');exit;}}
function csrf(){if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(32));return $_SESSION['csrf'];}
function verify_csrf(){if(!hash_equals(csrf(),$_POST['csrf']??'')){http_response_code(403);exit('Invalid request token');}}
